package com.example.pr_23

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.example.pr_23.databinding.ActivitySignInBinding

class SignInActivity : Activity() {

    private lateinit var binding: ActivitySignInBinding
    lateinit var email: EditText;
    lateinit var password: EditText;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
    }

    fun sign(view: View) {
        if(email.text.isNotEmpty() && password.text.isNotEmpty()) {
            val intent = Intent(this@SignInActivity, ResultActivity::class.java);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Введите почту и пароль", Toast.LENGTH_SHORT).show()
        }
    }
}